require('dotenv').config();
var app = require('./server');

app.listen(9000, function () {
  console.log('listening on port: 9000');
});
