#Blue Shield of California    medical    BS CA Trio ACO HMO    blueshieldofcalifornia-bscatrioacohmo
/usr/bin/curl -X GET --header "Accept: application/json" --header "Cache-Control: no-cache" "https://api.betterdoctor.com/2016-03-01/doctors?insurance_uid=blueshieldofcalifornia-bscatrioacohmo&location=37.773%2C-122.413%2C100&user_location=37.773%2C-122.413&skip=0&limit=10&user_key=7711e2c462a8d41fb06e3305b6d225ed" > response/blueshieldofcalifornia-bscatrioacohmo.json


#Blue Shield of California    medical    Blue Shield CA PPO    blueshieldofcalifornia-blueshieldcappo
/usr/bin/curl -X GET --header "Accept: application/json" --header "Cache-Control: no-cache" "https://api.betterdoctor.com/2016-03-01/doctors?insurance_uid=blueshieldofcalifornia-blueshieldcappo&location=37.773%2C-122.413%2C100&user_location=37.773%2C-122.413&skip=0&limit=10&user_key=7711e2c462a8d41fb06e3305b6d225ed" > response/blueshieldofcalifornia-blueshieldcappo.json
