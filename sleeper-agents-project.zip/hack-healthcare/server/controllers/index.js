module.exports = {
  doctors: require('./doctors')
}
