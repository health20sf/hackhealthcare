var request = require('request-promise');
var _ = require('lodash');
var Q = require('q');

module.exports = (function () {
  var zipCodeCache = {};
  var a = 0;

  return {
    getDoctors: getDoctors
  };

  function getDoctors(req, res) {
    var memberLocation;
    return getPostalCodeCoordinates(req.query.postal_code, req.query.range)
      .then(function (location) {
        if (!location) {
          throw new Error('Error getting postal coordinates with postal code ' + req.query.postal_code);
        }
        memberLocation = location;
        return request.get({
          url: formatURL('doctors'),
          qs: {
            insurance_uid: Array.isArray(req.query.insurance_uid) ? req.query.insurance_uid.join() : req.query.insurance_uid,
            location: location,
            user_key: process.env.BETTER_DOCTOR_KEY
          }
        });
      })
      .then(function (response) {
        res.send({
          doctors: JSON.parse(response).data,
          member_location: memberLocation
        });
      })
      .catch(function (error) {
        res.status(500).send('Error getting doctors\n' + error.message);
      });
  }
  function getPostalCodeCoordinates(postalCode, range) {
    range = range || 100;
    var cacheKey = JSON.stringify(postalCode) + JSON.stringify(range);
    var previousRequest = _.cloneDeep(zipCodeCache[cacheKey]);
    var zipCodePromise;
    if (previousRequest) {
      zipCodePromise = Q.when(previousRequest);
    } else {
      a++;
      zipCodePromise = request
        .get({
          url: 'https://maps.googleapis.com/maps/api/geocode/json',
          qs: {
            address: postalCode,
            key: process.env.GOOGLE_MAPS_KEY
          }
        })
    }

    return zipCodePromise
      .then(function (response) {
        if (!previousRequest) {
          zipCodeCache[cacheKey] = _.cloneDeep(response);
        }
        var geoCodes = _.values(JSON.parse(response).results[0].geometry.location);
        geoCodes.push(range);
        return geoCodes.join();
      })
      .catch(function () {
        return null;
      });
  }

  function formatURL(endpoint) {
    const BASE_URL = 'https://api.betterdoctor.com/2016-03-01';
    return BASE_URL + '/' + endpoint;
  }
})();
