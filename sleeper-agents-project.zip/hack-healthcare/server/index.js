/**
 * Created by grantopher on 10/14/17.
 */
var request = require('request');
var express = require('express');
var path = require('path');
var controllers = require('./controllers');
var app = express();


app.get('/', function (req, res) {
    res.sendFile('/app/index.html', {root: path.join(__dirname, '..')});
});
app.use(express.static(path.join(__dirname, '..')));

app.get('/api/doctors', controllers.doctors.getDoctors);
app.get('/plans', function (req, res) {
    request.get('http://localhost:3000/plans', function(err, response, body){
        res.send(body);
    })
});
app.get('/members', function (req, res) {
    request.get('http://localhost:3000/members', function(err, response, body){
        res.send(body);
    })
});
app.get('/carriers', function (req, res) {
    request.get('http://localhost:3000/carriers', function(err, response, body){
        res.send(body);
    })
});
app.get('/specialties', function (req, res) {
    request.get('http://localhost:3000/specialties', function(err, response, body){
        res.send(body);
    })
});

app.get('*', function(req, res) {
  res.sendFile('/app/index.html', {root: path.join(__dirname, '..')}); // load the single view file (angular will handle the page changes on the front-end)
});

module.exports = app;
