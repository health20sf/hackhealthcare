(function () {
  'use strict';

  angular
    .module('sleeperAgentsApp')
    .component('doctorCardList', {
      templateUrl: 'app/views/doctorCardList.template.html',
      controller: 'DoctorCardListController',
      bindings: {
        doctors: '<'
      },
      controllerAs: 'vm'
    });
})();
