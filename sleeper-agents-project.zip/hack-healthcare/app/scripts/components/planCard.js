/**
 * Created by grantopher on 10/14/17.
 */

(function () {
    'use strict';

    angular
        .module('sleeperAgentsApp')
        .component('planCard', {
            templateUrl: 'app/views/planCard.template.html',
            controller: 'PlanCardController',
            bindings: {
                plan: '<',
                cardstate: '<',
                doctors: '<'
            },
            controllerAs: 'vm'
        });
})();
