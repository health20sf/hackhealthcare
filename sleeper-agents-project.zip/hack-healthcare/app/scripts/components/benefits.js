/**
 * Created by grantopher on 10/14/17.
 */

(function () {
    'use strict';

    angular
        .module('sleeperAgentsApp')
        .component('benefits', {
            templateUrl: 'app/views/benefits.template.html',
            controller: 'BenefitsController',
            controllerAs: 'vm'
        });
})();
