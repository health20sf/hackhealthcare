(function () {
  'use strict';

  angular
    .module('sleeperAgentsApp')
    .component('doctorCard', {
      templateUrl: 'app/views/doctorCard.template.html',
      controller: 'DoctorCardController',
      bindings: {
        doctor: '<'
      },
      controllerAs: 'vm'
    });
})();
