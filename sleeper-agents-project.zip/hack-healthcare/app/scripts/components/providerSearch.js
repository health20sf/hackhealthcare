/**
 * Created by grantopher on 10/14/17.
 */

(function () {
    'use strict';

    angular
        .module('sleeperAgentsApp')
        .component('providerSearch', {
            templateUrl: 'app/views/providerSearch.template.html',
            controller: 'ProviderSearchController',
            controllerAs: 'vm'
        });
})();
