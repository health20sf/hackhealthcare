(function () {
  'use strict';

  angular
    .module('sleeperAgentsApp')
    .factory('BetterDoctorApi', BetterDoctorApi);

  BetterDoctorApi.$inject = ['$q', '$http', 'DelayPromise'];

  function BetterDoctorApi($q, $http, DelayPromise) {
    var cache = {};

    return {
      getDoctorsByUID: getDoctorsByUID,
      getDoctorsByPlanList: getDoctorsByPlanList
    };

    function getDoctorsByUID(insurance_uid, postalCode, range, retry) {
      var params = {
            insurance_uid: insurance_uid,
            postal_code: postalCode,
            range: range || 100,
            limit: 30
          }
        var cacheKey = JSON.stringify(params);
        var previousRequest = checkCache(cacheKey);
        if (previousRequest) {
            return $q.resolve(previousRequest);
        }

      return $http
        .get('/api/doctors',
            {
          params: params
        })
        .then(function (response) {
            cache[cacheKey] = _.cloneDeep(response.data);
            cache[cacheKey] = response.data;
            return response.data;
        }, function (error) {
          if (error.status === 500 && !retry) {
            return DelayPromise.delayPromise(500, getDoctorsByUID, [insurance_uid, postalCode, range]);
          }
        });
    }

    function getDoctorsByPlanList(planList, options) {
        var uids = _.uniq(_.map(planList, 'insurance_uids'));
        options.limit = options.limit > 100 ? 100 : options.limit;
        var params = {
            insurance_uid: uids,
            postal_code: options.postalCode,
            range: options.range || 100,
            limit: options.limit || 30
        };
        var cacheKey = JSON.stringify(params);
        var previousRequest = checkCache(cacheKey);
        if (previousRequest) {
            return $q.resolve(previousRequest);
        }

        return $http
          .get('api/doctors', {
            params: params
          })
          .then(function (response) {
            cache[cacheKey] = _.cloneDeep(response.data);
            return response.data;
          })
          .catch(function (error) {
            if (error.status === 500) {
              return DelayPromise.delayPromise(500, getDoctorsByPlanList, [planList, options]);
            }
          });
    }

    function checkCache(key) {
        if (cache[key]) {
            return _.cloneDeep(cache[key])
        }
        return false;
    }
  }
})();
