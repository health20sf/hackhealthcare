(function () {
    'use strict';

    angular
        .module('sleeperAgentsApp')
        .factory('Specialties', Specialties);

    function Specialties($http) {
        var factory = {
            getSpecialtiesData: getSpecialtiesData
        }

        function getSpecialtiesData() {
            return $http({
                method: 'GET',
                url: '/specialties'
            }).then(extract);

        }

        function extract(response) {
            return response.data;
        }
        return factory;
    }
})();
