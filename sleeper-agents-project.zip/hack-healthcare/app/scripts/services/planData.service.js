(function () {
    'use strict';

    angular
        .module('sleeperAgentsApp')
        .factory('PlanData', PlanData);

    function PlanData($http, $q) {
        var factory = {
            getPlanData: getPlanData,
            getCarrierLogo: getCarrierLogo,
            attachLogoToPlan: attachLogoToPlan
        }

        var carrierData = {};
        var carrierPromise;

        function getPlanData() {
            return $http({
                method: 'GET',
                url: '/plans'
            })
                .then(extract)
                .then(attachCarrierLogos);

        }

        function attachCarrierLogos(planData) {
            _.each(planData, attachLogoToPlan);
            return planData;
        }

        function attachLogoToPlan(plan) {
            getCarrierLogo(plan.carrier_id)
                .then(function (carrier_logo) {
                    plan.carrier_logo = carrier_logo;
                })
        }

        function getCarrierLogo(id) {
            return getCarrierData()
                .then(function (carrierData) {
                    return carrierData[id];
                })
        }

        function getCarrierData() {
            var promise = carrierPromise;
            if (!promise) {
                promise = $http({
                    method: 'GET',
                    url: '/carriers'
                });
                carrierPromise = promise;
            }
            return promise
                .then(extract)
                .then(save.bind(null, carrierData));
        }

        function save(saveObject, carrierData) {
            saveObject = carrierData;
            return carrierData;
        }
        function extract(response) {
            return response.data;
        }
        return factory;
    }
})();