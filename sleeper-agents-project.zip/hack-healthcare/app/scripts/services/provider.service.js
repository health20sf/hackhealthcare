(function () {
    'use strict';

    angular
        .module('sleeperAgentsApp')
        .factory('Provider', Provider);

    function Provider() {
        var factory = {
            getDoctorsOnPlan: getDoctorsOnPlan,
            compareDoctorPlans: compareDoctorPlans,
            targetDoctors: []
        }

        function getDoctorsOnPlan(plan, doctors) {
            var planInsuranceId = plan.insurance_uids;
            return _.filter(doctors, function (doctor) {
                return _.some(doctor.insurances, function (insurance) {
                    return insurance.insurance_plan.uid === planInsuranceId;
                });
            });
        }

        function compareDoctorPlans(basePlanDoctors) {
            basePlanDoctors = _.map(basePlanDoctors, 'uid');
            var commonDoctors = _.intersection(basePlanDoctors, _.map(factory.targetDoctors, 'uid'));
            var missingDoctors = _.difference(basePlanDoctors, commonDoctors);
            var percentCoverage = 100 * (commonDoctors.length / basePlanDoctors.length);
            return {
                commonDoctors: commonDoctors,
                missingDoctors: missingDoctors,
                percentCoverage: percentCoverage
            }
        }

        return factory;
    }
})();