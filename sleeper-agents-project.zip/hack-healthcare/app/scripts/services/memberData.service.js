(function () {
    'use strict';

    angular
        .module('sleeperAgentsApp')
        .factory('MemberData', MemberData);

    function MemberData($http) {
        var factory = {
            getMemberData: getMemberData
        }

        function getMemberData() {
            return $http({
                method: 'GET',
                url: '/members'
            }).then(extract);

        }

        function extract(response) {
            return response.data;
        }
        return factory;
    }
})();
