(function () {
    'use strict';

    angular
        .module('sleeperAgentsApp')
        .factory('DelayPromise', DelayPromise);

    function DelayPromise($q) {
        var factory = {
            delayPromise: delayPromise
        }
        /**
         * @method Delay Promise
         * @description
         * Delays a function call by a set amount of time, returning a promise that resolves when that delay is complete.
         *
         * @param {Number} time to delay in ms
         * @param {Function} the function call that we are delaying
         * @param {Object} data the object that the callback is being invoked on.
         *
         * @returns {Promise} A promise that resolves the callback on the data after the delay.
         */
        function delayPromise(delay, callback, args) {
            var differed = $q.defer();
            setTimeout(function () {
                return differed.resolve(callback.apply(null, args));
            }, delay);
            return differed.promise;

        }
        return factory;
    }
})();
