
(function () {
    'use strict';

    angular
        .module('sleeperAgentsApp')
        .controller('BenefitsController', function (PlanData) {
            var vm = this;

            PlanData.getPlanData().then(function (planData) {
                vm.planData = planData;
            });
        });
})();
