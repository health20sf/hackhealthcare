/**
 * Created by grantopher on 10/14/17.
 */

(function () {
    'use strict';

    angular
        .module('sleeperAgentsApp')
        .controller('PlanCardController', function ($q, BetterDoctorApi, $scope, Provider) {
            var vm = this;
            $q.when(vm.plan).then(function () {
                return BetterDoctorApi.getDoctorsByUID(vm.plan.insurance_uids, '96003', 40);
            }).then(function (response) {
                vm.allDoctors = _.map(response.doctors, function (doctor) {
                    doctor.name = getName(doctor);
                    return doctor;
                });
                vm.shownDoctors = _.clone(response.doctors);
            });

            vm.getName = getName;
            vm.search = search;
            vm.searchText = '';
            vm.getName = getName;
            vm.getLocation = getLocation;
            vm.getCoverage = getCoverage;
            vm.missingDoctors = missingDoctors;
            vm.selectAsTargetPlan = selectAsTargetPlan;
            vm.canShowCoveragePercent = canShowCoveragePercent;
            vm.canShowFullCoverage = canShowFullCoverage;
            vm.canShowCompareButton = canShowCompareButton;
            vm.isTargetPlan = false;


            function canShowCoveragePercent() {
                return vm.cardstate === 'comparison' && !vm.isTargetPlan && getCoverage() < 100;
            }

            function canShowFullCoverage() {
                return vm.cardstate === 'comparison' && !vm.isTargetPlan && getCoverage() === 100;
            }

            function canShowCompareButton() {
                return vm.cardstate === 'selectTargetPlan';
            }

            function getCoverage() {
                return Provider.compareDoctorPlans(vm.allDoctors).percentCoverage;
            }

            function missingDoctors() {
                return Provider.compareDoctorPlans(vm.allDoctors).missingDoctors.length;
            }

            function getName(doctor) {
                var first = doctor.profile.first_name || '';
                var middle = doctor.profile.middle_name || '';
                var last = doctor.profile.last_name || '';
                return first + ' ' + middle + ' ' + last;
            }
            function search() {
                if (vm.searchText.length) {
                    vm.shownDoctors = _.filter(vm.allDoctors, function (doctor) {
                        return doctor.name.toLowerCase().includes(vm.searchText.toLowerCase());
                    });
                    return vm.shownDoctors;
                } else {
                    vm.shownDoctors = _.clone(vm.allDoctors);
                    return vm.shownDoctors;
                }
            }

            function selectAsTargetPlan() {
                $scope.$emit('selectTargetPlan', vm.plan.plan_id, vm.allDoctors);
                vm.isTargetPlan = true;
            }

            function getLocation(doctor) {
                return doctor.practices[0].city;
            }
        });
})();

