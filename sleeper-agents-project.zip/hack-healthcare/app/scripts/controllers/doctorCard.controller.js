(function () {
  'use strict';

  angular
    .module('sleeperAgentsApp')
    .controller('DoctorCardController', function ($scope) {
        var vm = this;
        vm.getDoctorName = getDoctorName;
        vm.hasBetterDoctorRating = hasBetterDoctorRating;
        vm.getBetterDoctorRatingImage = getBetterDoctorRatingImage;
        vm.getLocation = getLocation;
        vm.hasLocation = hasLocation;
        vm.getDescription = getDescription;
        vm.showMessage = showMessage;
        vm.toggleDescriptionLength = toggleDescriptionLength;
        vm.updateMapCenter = updateMapCenter;
        vm.showMore = false;

        function getDoctorName() {
          var doctorNames = [vm.doctor.profile.first_name, vm.doctor.profile.middle_name, vm.doctor.profile.last_name];
          return doctorNames.join(' ') + ', ' + vm.doctor.profile.title;
        }

        function showMessage() {
            return ' show ' + (vm.showMore ? 'less' : 'more') + '...'
        }

        function getDescription() {
          return !vm.showMore ? vm.doctor.profile.bio.slice(0, 75) : vm.doctor.profile.bio;
        }

        function toggleDescriptionLength() {
          vm.showMore = !vm.showMore;
        }

        function hasBetterDoctorRating() {
          return vm.doctor.ratings.length > 0 && _.find(vm.doctor.ratings, {provider: 'betterdoctor'}) !== undefined;
        }

        function getLocation(type) {
          var location = vm.doctor.practices[0].visit_address;
          switch(type) {
            case 'street':
              return location.street + (location.street2 ? ' ' + location.street2 : '');
            case 'city_state_zip':
              return location.city + ', ' + location.state + ' ' + location.zip;
          }
        }

        function hasLocation() {
          return vm.doctor.practices.length > 0;
        }

        function updateMapCenter(doctor) {
            var practice = doctor.practices[0];
            $scope.$emit('updateMapCenter', practice.lat + ',' + practice.lon);
        }

        function getBetterDoctorRatingImage() {
          var rating = _.find(vm.doctor.ratings, {provider: 'betterdoctor'});
          return rating.image_url_small;
        }
    });
})();
