'use strict';

/**
 * @ngdoc function
 * @name sleeperAgentsApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the sleeperAgentsApp
 */
angular.module('sleeperAgentsApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
