(function () {
  'use strict';

  angular
    .module('sleeperAgentsApp')
    .controller('DoctorCardListController', function (BetterDoctorApi) {
      var vm = this;
      // vm.doctors = [];
      // BetterDoctorApi.getDoctorsByUID('medicare-medicare', '94110', 40)
      //   .then(function (doctors) {
      //     vm.doctors = doctors;
      //   });
    });
})();
