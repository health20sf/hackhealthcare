/**
 * Created by grantopher on 10/14/17.
 */

(function () {
    'use strict';

    angular
        .module('sleeperAgentsApp')
        .controller('ProviderSearchController', function (Provider, BetterDoctorApi, PlanData, MemberData, Specialties, NgMap, $scope, $mdDialog, $q) {
            var vm = this;
            vm.targetPlan;
            vm.targetZIP;
            vm.targetUID;

            //maps
            vm.googleMapsUrl = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyD3AGLcxNkdZ0DYvaBvsYmv94kVvXj36E4';
            vm.promptTargetPlanSelect = promptTargetPlanSelect;
            vm.onMemberSelect = onMemberSelect;
            vm.cardState = 'selectTargetPlan';
            vm.isTargetPlan = isTargetPlan;
            vm.onPlanSelect = onPlanSelect;
            vm.updatingDoctorList = false;

            initialize();

            function initialize() {
                $q.all({
                    plans: PlanData.getPlanData(),
                    map: NgMap.getMap(),
                    members: MemberData.getMemberData(),
                    specialties: Specialties.getSpecialtiesData()
                }).then(function (response) {
                    vm.targetZIP = response.members[0].zip;
                    response.doctors = BetterDoctorApi.getDoctorsByPlanList(response.plans, {postalCode: vm.targetZIP})
                    return $q.all(response);
                }).then(function (response) {
                    vm.plans = response.plans;
                    vm.members = response.members;
                    vm.doctors = response.doctors.doctors;
                    vm.specialties = response.specialties;
                    vm.mapLocation = response.doctors.member_location
                }).then(setMap);


                $scope.$on('selectTargetPlan', function (event, targetPlanID, doctors) {
                    vm.targetPlan = _.find(vm.plans, {plan_id: targetPlanID});
                    Provider.targetDoctors = doctors;
                    orderPlanCards(targetPlanID);
                    changeTabState('comparison');
                });

              $scope.$on('updateMapCenter', function (event, center) {
                  vm.centerMap = center;
              });
            }

            function setMap() {
                vm.mapMarkers = getDoctorMarkers();
                vm.centerMap = vm.mapLocation;
            }

            function onPlanSelect() {
                vm.targetUID = vm.selectedPlan.insurance_uids;
                return BetterDoctorApi.getDoctorsByUID(vm.targetUID, vm.targetZIP)
                  .then(function (response) {
                    vm.doctors = response.doctors;
                  })
                  .then(setMap);
            }

            function onMemberSelect() {
              vm.updatingDoctorList = true;
              var memberZIP = vm.selectedMember.zip;
              if (memberZIP !== vm.targetZIP) {
                $q.resolve()
                  .then(function () {
                    vm.targetZIP = memberZIP;
                    if (vm.targetUID) {
                        return BetterDoctorApi.getDoctorsByPlanList(vm.plans, {postalCode: vm.targetZIP})
                    } else {
                        return BetterDoctorApi.getDoctorsByUID(vm.targetUID, {postalCode: vm.targetZIP})
                    }
                  })
                  .then(function (response) {
                      vm.mapLocation = response.member_location;
                      vm.doctors = response.doctors;
                      vm.updatingDoctorList = false;
                  })
                  .then(setMap);
              }
            }

            function orderPlanCards(targetPlanID) {
                vm.plans = _.sortBy(vm.plans, function (plan) {
                    return plan.plan_id !== targetPlanID;
                });
            }

            function changeTabState(state) {
                vm.cardState = state;
            }

            function isTargetPlan(planID) {
                if (!vm.targetPlan) {
                    return false;
                }
                return planID === vm.targetPlan.plan_id;
            }

            function promptTargetPlanSelect() {
                if (vm.targetPlan) {
                    return false;
                }

                return $mdDialog.show($mdDialog
                    .alert()
                    .title('Select Target Plan!')
                    .content('Please select which plan you would like to compare against')
                    .ok('OK'));
            }

            function getDoctorMarkers() {
               return _.map(vm.doctors, function (doctor) {
                   var practice = doctor.practices[0];
                   return [practice.lat, practice.lon];
               })
            }
        });
})();
