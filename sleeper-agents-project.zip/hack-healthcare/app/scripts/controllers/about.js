'use strict';

/**
 * @ngdoc function
 * @name sleeperAgentsApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the sleeperAgentsApp
 */
angular.module('sleeperAgentsApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
