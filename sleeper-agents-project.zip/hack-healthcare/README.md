# sleeper-agents

October 2017 - Google Hack Healthcare Team: Kyle Morehead, Erik Brown, Grant Carson & Joshua Martinez

Using Better Docotor API's to help serve up doctor information for our plan data. Benefits, Find Providers and Compare Providers.

## Dependencies

Run `npm install -g json-server`

Run `npm install && bower install`

## Running the application

Run `json-server --no-cors --watch data/db.json`

Run `node server/index.js`
