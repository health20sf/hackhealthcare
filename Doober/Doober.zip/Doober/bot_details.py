
Bot_cred = {
            'SLACK_BOT_TOKEN' : 'xoxb-255938991152-xwsZFRoSkCNG8VTx4msK4wAc',
            'BOT_NAME' :'doober_bot',
            'BOT_ID' :''
}